#!/bin/sh
# script to print user information

echo "Hello $USER"
#greet the user

echo -n "Nmber of logins: "; who|wc -l
#print number of users logged in

echo "Calendar" cal
# show a calendar of the curent month

echo -n "today is "; date
#print "today is" along with the current date and time

exit 0
#end the shell script
